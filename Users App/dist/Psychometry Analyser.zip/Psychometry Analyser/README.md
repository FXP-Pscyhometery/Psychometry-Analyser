# FXP-Psychometry-Analyser
![alt text](Logo.png?raw=true)


Hebrew explaination and project page :

Psychometry Analyser is an open source software in a CLI interface for documentation and analysis of users Psychometry simulations and practice tests.
The software let's the user upload his results to a local database, and the software compare and analyse accourding to the correct results that are on the online database.

The software is suppose to be simple and easy to use, and very much guided thorugh use.

In this repository, you have the source code for the Users app, and the Management app.

The Users app is the one meant for users.
The Management meant for moderators/managers that are maintaining the online database and keeping it updated.
(The management app create a new version/file of the online database, localy. to be able to update the online database, you need to contact the creator.)


Installation is easy, just download the release zip file you need, and save the application where you want.
(Note to users: the software creates and saves your local database, in the folder "LocalDB", which will be saved under your OS user home directory.)


As of now, there is only a distribution for windows users, 
and also many limitations since it's a CLI in windows( CommandLine or CMD )

Here are the main ones:

1)You can only scroll up and down using the CLI interface 'scroller' on the far side of the application.

2)Only English support as of now.
  You can enter non-English input alphabet, but you won't be able to see what you have entered, and the interface won't print it for you.
  
  
 
Creator Credits to the software (not the 3rd party libraries of course) goes to @gilbear and @gilkzxc.
